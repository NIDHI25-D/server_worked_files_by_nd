from odoo import fields, models, api, _


class RFMSegment(models.Model):
    _inherit = 'setu.rfm.segment'

    pos_order_ids = fields.One2many(comodel_name='pos.order', inverse_name='rfm_segment_id',
                                    string="Pos Orders by Company")
    team_pos_order_ids = fields.One2many(comodel_name='pos.order', inverse_name='rfm_team_segment_id',
                                         string="Pos Orders by Sales Team")

    total_pos_orders = fields.Integer(string="Total POS Orders", compute='_compute_rfm_common')

    total_pos_revenue = fields.Float(string="Total POS Revenue", compute='_compute_rfm_common')
    total_pos_orders_ratio = fields.Float(string="POS Orders", compute='_compute_rfm_common')
    total_pos_revenue_ratio = fields.Float(string="POS Revenue", compute='_compute_rfm_common')

    def _compute_rfm_common(self):
        """
        added by: Riken Mashru | On : OCt-23-2024 | Task: [903] Migration 18 : RFM Analysis - Marketing Strategy
        use : to compute various metrics related to RFM (Recency, Frequency, Monetary) analysis for sales teams or
        company segments
        """
        company_id = self._context.get('allowed_company_ids')[0]
        team = self.mapped('crm_team_id')
        if len(team) == 1:
            team_id = team.id
            company_id = 0
        else:
            team_id = 0
        self._cr.execute(f"select * from compute_rfm_sp_extended({company_id},{team_id},ARRAY{str(self.ids)});")
        rfm_compute_values = self._cr.dictfetchall()
        rfm_compute_values = self.transform_to_dict(rfm_compute_values)
        for segment in self:
            data = rfm_compute_values[segment.id]
            if segment.is_template:
                segment.update({
                    'total_customers': data['partners'],
                    'total_orders': data['company_wise_sales'],
                    'total_revenue': data['company_wise_revenue'],
                    'total_customers_ratio': data['partner_ratio'],
                    'total_orders_ratio': data['sales_ratio'],
                    'total_revenue_ratio': data['revenue_ratio'],
                    'total_pos_orders': data['company_wise_pos'],
                    'total_pos_revenue': data['company_wise_revenue_pos'],
                    'total_pos_orders_ratio': data['pos_ratio'],
                    'total_pos_revenue_ratio': data['pos_revenue_ratio']
                })
            else:
                segment.update({'total_customers': data['team_partners'],
                                'total_orders': data['sales_team_wise_sales'],
                                'total_revenue': data['sales_team_wise_revenue'],
                                'total_customers_ratio': data['team_partners_ratio'],
                                'total_orders_ratio': data['team_sales_ratio'],
                                'total_revenue_ratio': data['team_revenue_ratio'],
                                'total_pos_orders': data['sales_team_wise_pos'],
                                'total_pos_revenue': data['sales_team_wise_revenue_pos'],
                                'total_pos_orders_ratio': data['team_pos_ratio'],
                                'total_pos_revenue_ratio': data['team_pos_revenue_ratio']
                                })

    def open_pos_orders(self):
        """
        added by: Riken Mashru | On : OCt-23-2024 | Task: [903] Migration 18 : RFM Analysis - Marketing Strategy
        use : to open Point of Sale (POS) orders
        """
        form_view_id = self.env.ref('point_of_sale.view_pos_pos_form').id
        tree_view_id = self.env.ref('point_of_sale.view_pos_order_tree').id
        report_display_views = [(tree_view_id, 'list'), (form_view_id, 'form')]
        if self.is_template:
            ids = self.pos_order_ids.ids
        else:
            ids = self.team_pos_order_ids.ids
        return {
            'name': _(self.name + ' -> ' + 'POS Order'),
            'domain': [('id', 'in', ids)],
            'res_model': 'pos.order',
            'view_mode': "list,form",
            'type': 'ir.actions.act_window',
            'views': report_display_views,
        }

    def open_pos_rfqs(self):
        """
        added by: Riken Mashru | On : OCt-23-2024 | Task: [903] Migration 18 : RFM Analysis - Marketing Strategy
        use : to open Point of Sale (POS) quotations related to specific partners
        """
        form_view_id = self.env.ref('point_of_sale.view_pos_pos_form').id
        tree_view_id = self.env.ref('point_of_sale.view_pos_order_tree').id
        report_display_views = [(tree_view_id, 'tree'), (form_view_id, 'form')]
        partners = self.partner_ids and self.partner_ids.ids or []
        return {
            'name': _(self.name + ' -> ' + 'POS Quotation'),
            'domain': [('state', 'in', ['draft', 'sent']), ('partner_id', 'in', partners)],
            'res_model': 'pos.order',
            'view_mode': "tree,form",
            'type': 'ir.actions.act_window',
            'views': report_display_views,
        }

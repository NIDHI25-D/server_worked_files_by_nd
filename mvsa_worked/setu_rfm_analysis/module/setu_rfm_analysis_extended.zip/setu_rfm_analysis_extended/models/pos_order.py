from odoo import fields, models, api, _


class PointOfSale(models.Model):
    _inherit = 'pos.order'

    rfm_segment_id = fields.Many2one(comodel_name="setu.rfm.segment", copy=False, string='RFM Segment')
    rfm_team_segment_id = fields.Many2one(comodel_name='setu.rfm.segment', string='RFM Sales Team Segment',
                                          help='RFM Segment Sales Team Wise.', copy=False)



DROP FUNCTION IF EXISTS public.compute_rfm_sp_extended(integer, integer, integer[]);
CREATE OR REPLACE FUNCTION public.compute_rfm_sp_extended(
    IN active_company_id integer,
    IN current_team_id integer,
    IN segment_ids integer[]
)
RETURNS TABLE(
    segment_id integer,
    revenue_ratio double precision,
    sales_ratio double precision,
    partner_ratio double precision,
    team_revenue_ratio double precision,
    team_sales_ratio double precision,
    pos_revenue_ratio double precision,
    pos_ratio double precision,
    team_pos_revenue_ratio double precision,
    team_pos_ratio double precision,
    partners numeric,
    company_wise_sales numeric,
    sales_team_wise_sales numeric,
    company_wise_revenue numeric,
    sales_team_wise_revenue numeric,
    company_wise_pos numeric,
    sales_team_wise_pos numeric,
    company_wise_revenue_pos numeric,
    sales_team_wise_revenue_pos numeric,
    team_partners numeric,
    team_partners_ratio numeric
) AS
$BODY$
DECLARE
    total_customers_company numeric := (SELECT total_customers FROM overall_company_customer_data(active_company_id))::numeric;
    total_revenue_company numeric := (SELECT total_revenue FROM overall_company_data(active_company_id))::numeric;
    total_orders_company numeric := (SELECT total_orders FROM overall_company_data(active_company_id))::numeric;
    total_revenue_sales_team numeric := (SELECT total_revenue FROM overall_team_data(current_team_id))::numeric;
    total_orders_sales_team numeric := (SELECT total_orders FROM overall_team_data(current_team_id))::numeric;

    total_pos_revenue_company numeric := (SELECT total_revenue FROM overall_company_data_pos(active_company_id))::numeric;
    total_pos_orders_company numeric := (SELECT total_orders FROM overall_company_data_pos(active_company_id))::numeric;

    total_pos_revenue_sales_team numeric := (SELECT total_revenue FROM overall_team_data_pos(current_team_id))::numeric;
    total_pos_orders_sales_team numeric := (SELECT total_orders FROM overall_team_data_pos(current_team_id))::numeric;

BEGIN
    RETURN QUERY
    SELECT
        segment_data.id as segment_id,
        CASE WHEN total_revenue_company > 0 THEN
            ROUND((100 * MAX(segment_data.company_wise_revenue)::float / total_revenue_company))
        ELSE 0 END AS revenue_ratio,

        CASE WHEN total_orders_company > 0 THEN
            ROUND((100 * MAX(segment_data.company_wise_sales)::float / total_orders_company))
        ELSE 0 END AS sales_ratio,

        CASE WHEN total_customers_company > 0 THEN
            ROUND((100 * MAX(segment_data.partners)::float / total_customers_company))
        ELSE 0 END AS partner_ratio,

        CASE WHEN total_revenue_sales_team > 0 THEN
            ROUND((100 * MAX(segment_data.sales_team_wise_revenue)::float / total_revenue_sales_team))
        ELSE 0 END AS team_revenue_ratio,

        CASE WHEN total_orders_sales_team > 0 THEN
            ROUND((100 * MAX(segment_data.sales_team_wise_sales)::float / total_orders_sales_team))
        ELSE 0 END AS team_sales_ratio,

        CASE WHEN total_pos_revenue_company > 0 THEN
            ROUND((100 * MAX(segment_data.company_wise_pos_revenue)::float / total_pos_revenue_company))
        ELSE 0 END AS pos_revenue_ratio,

        CASE WHEN total_pos_orders_company > 0 THEN
            ROUND((100 * MAX(segment_data.company_wise_pos)::float / total_pos_orders_company))
        ELSE 0 END AS pos_ratio,

        CASE WHEN total_pos_revenue_sales_team > 0 THEN
            ROUND((100 * MAX(segment_data.sales_team_wise_pos_revenue)::float / total_pos_revenue_sales_team))
        ELSE 0 END AS team_pos_revenue_ratio,

        CASE WHEN total_pos_orders_sales_team > 0 THEN
            ROUND((100 * MAX(segment_data.sales_team_wise_pos)::float / total_pos_orders_sales_team))
        ELSE 0 END AS team_pos_ratio,

        MAX(segment_data.partners)::numeric AS partners,
        MAX(segment_data.company_wise_sales)::numeric AS company_wise_sales,
        MAX(segment_data.sales_team_wise_sales)::numeric AS sales_team_wise_sales,
        MAX(segment_data.company_wise_revenue) AS company_wise_revenue,
        MAX(segment_data.sales_team_wise_revenue) AS sales_team_wise_revenue,
        MAX(segment_data.company_wise_pos)::numeric AS company_wise_pos,
        MAX(segment_data.sales_team_wise_pos)::numeric AS sales_team_wise_pos,
        MAX(segment_data.company_wise_pos_revenue) AS company_wise_pos_revenue,
        MAX(segment_data.sales_team_wise_pos_revenue) AS sales_team_wise_pos_revenue,
        max(segment_data.team_partners) as team_partners,
        max(segment_data.team_partners_ratio) as team_partners_ratio
    FROM
    (
      select
		s.id,
		s.partners as partners,
		0 as company_wise_sales,
		0 as sales_team_wise_sales,
		0 as company_wise_revenue,
		0 as sales_team_wise_revenue,
		0 as company_wise_pos,
		0 as sales_team_wise_pos,
		0 as company_wise_pos_revenue,
		0 as sales_team_wise_pos_revenue,
		sum(s.partners) over()::numeric as team_partners,
		round((s.partners / case when (sum(s.partners) over()) > 0 then (sum(s.partners) over()) else 1 end)::numeric*100) as team_partners_ratio
		from
		(
            select
                srs.id,
                count(ps.partner_id) as partners,
                0 as company_wise_sales,
                0 as sales_team_wise_sales,
                0 as company_wise_revenue,
                0 as sales_team_wise_revenue,
                0 as company_wise_pos,
                0 as sales_team_wise_pos,
                0 as company_wise_pos_revenue,
                0 as sales_team_wise_pos_revenue,
                sum(distinct ps.partner_id) as team_partners


            from
            setu_rfm_segment srs
            left join partner_segments ps on srs.id = ps.segment_id
            where srs.is_template = false and srs.id = any(segment_ids)
            group by srs.id
            )s

        UNION ALL

        SELECT
            srs.id,
            (
                SELECT
                    COUNT(*)
                FROM
                    res_partner
                WHERE
                    jsonb_pretty(rfm_segment_id ->active_company_id::text)::integer = srs.id
            ) AS partners,
            0 AS company_wise_sales,
            0 AS sales_team_wise_sales,
            0 AS company_wise_revenue,
            0 AS sales_team_wise_revenue,
            0 AS company_wise_pos,
            0 AS sales_team_wise_pos,
            0 AS company_wise_pos_revenue,
            0 AS sales_team_wise_pos_revenue,
            0 as team_partners,
		    0 as team_partners_ratio
        FROM
            setu_rfm_segment srs
        WHERE
            srs.is_template = true AND srs.id = ANY(segment_ids)
        GROUP BY
            srs.id

        UNION ALL

        SELECT
            srs.id,
            0 AS partners,
            COUNT(so.id)::numeric AS company_wise_sales,
            0 AS sales_team_wise_sales,
            COALESCE(SUM(so.amount_total), 0) AS company_wise_revenue,
            0 AS sales_team_wise_revenue,
            0 AS company_wise_pos,
            0 AS sales_team_wise_pos,
            0 AS company_wise_pos_revenue,
            0 AS sales_team_wise_pos_revenue,
            0 as team_partners,
		    0 as team_partners_ratio
        FROM
            setu_rfm_segment srs
            LEFT JOIN sale_order so ON so.rfm_segment_id = srs.id AND so.company_id = active_company_id
        WHERE
            srs.id = ANY(segment_ids)
        GROUP BY
            srs.id

        UNION ALL

        SELECT
            srs.id,
            0 AS partners,
            0 AS company_wise_sales,
            COUNT(so2.id)::numeric AS sales_team_wise_sales,
            0 AS company_wise_revenue,
            COALESCE(SUM(so2.amount_total), 0) AS sales_team_wise_revenue,
            0 AS company_wise_pos,
            0 AS sales_team_wise_pos,
            0 AS company_wise_pos_revenue,
            0 AS sales_team_wise_pos_revenue,
            0 as team_partners,
		    0 as team_partners_ratio
        FROM
            setu_rfm_segment srs
            LEFT JOIN sale_order so2 ON so2.rfm_team_segment_id = srs.id
        WHERE
            srs.id = ANY(segment_ids)
        GROUP BY
            srs.id

        UNION ALL

        SELECT
            srs.id,
            0 AS partners,
            0 AS company_wise_sales,
            0 AS sales_team_wise_sales,
            0 AS company_wise_revenue,
            0 AS sales_team_wise_revenue,
            COUNT(c.*)::numeric AS company_wise_pos,
            0 AS sales_team_wise_pos,
            SUM(c.amount_total) AS company_wise_pos_revenue,
            0 AS sales_team_wise_pos_revenue,
            0 as team_partners,
		    0 as team_partners_ratio
        FROM
            setu_rfm_segment srs
            LEFT JOIN pos_order c ON c.rfm_segment_id = srs.id AND c.company_id = active_company_id
        WHERE
            srs.id = ANY(segment_ids)
        GROUP BY
            srs.id

        UNION ALL

        SELECT
            srs.id,
            0 AS partners,
            0 AS company_wise_sales,
            0 AS sales_team_wise_sales,
            0 AS company_wise_revenue,
            0 AS sales_team_wise_revenue,
            0 AS company_wise_pos,
            COUNT(pos_order_entry.*)::numeric AS sales_team_wise_pos,
            0 AS company_wise_pos_revenue,
            SUM(pos_order_entry.amount_total) AS sales_team_wise_pos_revenue,
            0 as team_partners,
		    0 as team_partners_ratio
        FROM
            setu_rfm_segment srs
            LEFT JOIN pos_order pos_order_entry ON pos_order_entry.rfm_team_segment_id = srs.id
        WHERE
            srs.id = ANY(segment_ids)
        GROUP BY
            srs.id

    ) AS segment_data
    GROUP BY segment_data.id;
END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

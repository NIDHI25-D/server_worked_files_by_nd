DROP FUNCTION IF EXISTS public.gather_sales_and_pos_data(integer[], date, date);

CREATE OR REPLACE FUNCTION public.gather_sales_and_pos_data(
    IN company_ids integer[],
    IN start_date date,
    IN end_date date)
RETURNS void AS
$BODY$
DECLARE
    tr_start_date date := start_date;
    tr_end_date date := end_date;

BEGIN

    DROP TABLE IF EXISTS sales_data;

    CREATE TEMPORARY TABLE sales_data (
        so_id integer,
        pos_id integer,
        team_id integer,
        company_id integer,
        partner_id integer,
        date_order date,
        amount_total_per_line numeric,
        tax_amount numeric
    );

    INSERT INTO sales_data
    SELECT
        so.id AS so_id,
        NULL::integer AS pos_id,
        so.team_id,
        so.company_id,
        CASE WHEN rp.parent_id IS NULL THEN so.partner_id ELSE rp.parent_id END AS partner_id,
        so.date_order::date,
        SUM(
            CASE
                WHEN source.usage = 'internal' THEN
                    (sml.quantity * sol.price_unit) / COALESCE(NULLIF(so.currency_rate, 0), 1.0)
                ELSE
                    (-1 * sml.quantity * sol.price_unit) / COALESCE(NULLIF(so.currency_rate, 0), 1.0)
            END
        ) AS amount_total_per_line,
        SUM(
            CASE
                WHEN tax.price_include_override != 'true' THEN
                    CASE
                        WHEN source.usage = 'internal' THEN
                            (sml.quantity * sol.price_unit) / COALESCE(NULLIF(so.currency_rate, 0), 1.0)
                        ELSE
                            (-1 * sml.quantity * sol.price_unit) / COALESCE(NULLIF(so.currency_rate, 0), 1.0)
                    END
                ELSE 0
            END * (tax.amount / 100)
        ) AS tax_amount
    FROM
        stock_move move
        INNER JOIN stock_move_line sml ON sml.move_id = move.id
        INNER JOIN sale_order_line sol ON sol.id = move.sale_line_id
        LEFT JOIN account_tax_sale_order_line_rel tax_rel ON sale_order_line_id = sol.id
        LEFT JOIN account_tax tax ON tax.id = account_tax_id
        INNER JOIN sale_order so ON so.id = sol.order_id
        INNER JOIN stock_location source ON source.id = move.location_id
        INNER JOIN stock_location dest ON dest.id = move.location_dest_id
        LEFT JOIN stock_warehouse source_warehouse ON source.parent_path::text ~~ CONCAT('%/', source_warehouse.view_location_id, '/%')
        LEFT JOIN stock_warehouse dest_warehouse ON dest.parent_path::text ~~ CONCAT('%/', dest_warehouse.view_location_id, '/%')
        INNER JOIN res_partner rp ON rp.id = so.partner_id
        INNER JOIN res_company rc ON rc.id = so.company_id
    WHERE
        1 = CASE
            WHEN tr_start_date IS NULL THEN
                CASE WHEN DATE_PART('day', NOW()::timestamp - so.date_order::timestamp)::integer <= rc.take_sales_from_x_days::integer THEN 1 ELSE 0 END
            ELSE
                CASE WHEN so.date_order >= tr_start_date THEN 1 ELSE 0 END
            END
        AND so.date_order::date <= tr_end_date
        AND 1 = CASE
            WHEN array_length(company_ids, 1) >= 1 THEN
                CASE WHEN so.company_id = ANY(company_ids) THEN 1 ELSE 0 END
            ELSE 1
            END
        AND move.state = 'done'
    GROUP BY
        so.id, so.team_id, so.company_id, so.partner_id, rp.parent_id, so.date_order

    UNION ALL

    SELECT
        NULL::integer AS so_id,
        CASE WHEN SUM(pol.qty) > 0 THEN pos.id ELSE NULL::integer END AS pos_id,
        pc.crm_team_id AS team_id,
        pos.company_id,
        CASE WHEN rp.parent_id IS NULL THEN pos.partner_id ELSE rp.parent_id END AS partner_id,
        CASE WHEN SUM(pol.qty) > 0 THEN pos.date_order ELSE NULL::date END AS date_order,
        SUM(
            CASE
                WHEN pt.type IN ('combo', 'consu', 'service') THEN
                    CASE
                        WHEN pol.qty > 0 THEN
                            (pol.qty * ((100 - pol.discount) * pol.price_unit / 100)) / COALESCE(NULLIF(pos.currency_rate, 0), 1.0)
                        ELSE
                            (pol.qty * ((100 - pol.discount) * pol.price_unit / 100)) / COALESCE(NULLIF(pos.currency_rate, 0), 1.0)
                    END
                ELSE 0
            END
        ) AS amount_total_per_line,
        COALESCE(SUM(
            CASE
                WHEN tax.price_include_override != 'true' THEN
                    CASE
                        WHEN pt.type IN ('combo', 'consu', 'service') THEN
                            CASE
                                WHEN pol.qty > 0 THEN
                                    (pol.qty * ((100 - pol.discount) * pol.price_unit / 100)) / COALESCE(NULLIF(pos.currency_rate, 0), 1.0)
                                ELSE
                                    (pol.qty * ((100 - pol.discount) * pol.price_unit / 100)) / COALESCE(NULLIF(pos.currency_rate, 0), 1.0)
                            END
                        ELSE 0
                    END
                ELSE 0
            END * (tax.amount / 100)), 0) AS tax_amount
    FROM
        pos_order_line pol
        INNER JOIN pos_order pos ON pos.id = pol.order_id
        INNER JOIN pos_session ps ON ps.id = pos.session_id
        INNER JOIN pos_config pc ON pc.id = ps.config_id
        INNER JOIN product_product pro ON pol.product_id = pro.id
        INNER JOIN product_template pt ON pro.product_tmpl_id = pt.id
        LEFT JOIN account_tax_pos_order_line_rel tax_rel ON pos_order_line_id = pol.id
        LEFT JOIN account_tax tax ON tax.id = account_tax_id
        INNER JOIN res_partner rp ON rp.id = pos.partner_id
    WHERE
        1 = CASE
            WHEN tr_start_date IS NOT NULL AND tr_end_date IS NOT NULL THEN
                CASE WHEN (pos.date_order::date >= tr_start_date AND pos.date_order::date <= tr_end_date) THEN 1 ELSE 0 END
            ELSE 1
        END
        AND 1 = CASE
            WHEN array_length(company_ids, 1) >= 1 THEN
                CASE WHEN pos.company_id = ANY(company_ids) THEN 1 ELSE 0 END
            ELSE 1
        END
        AND pos.state::text = ANY (ARRAY['paid', 'invoiced', 'done'])
        AND pos.state NOT IN ('draft', 'cancel')
        AND pos.partner_id IS NOT NULL
        AND pc.crm_team_id IS NOT NULL
        AND pos.write_date < (SELECT NOW() - INTERVAL '1 hour')
    GROUP BY
        pos.id, pos.partner_id, rp.parent_id, pos.company_id, pc.crm_team_id, pos.date_order;

END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

DROP FUNCTION IF EXISTS public.overall_team_data_pos(integer);
CREATE OR REPLACE FUNCTION public.overall_team_data_pos(IN sales_team_id integer)
RETURNS TABLE(
    total_orders bigint,
    total_revenue numeric
) AS
$BODY$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(pos_order_entry.*) AS total_orders,
        SUM(pos_order_entry.amount_total) AS total_revenue
    FROM
        pos_order pos_order_entry
        LEFT JOIN pos_session pos_session_entry ON pos_session_entry.id = pos_order_entry.session_id
        LEFT JOIN pos_config pos_config_entry ON pos_config_entry.id = pos_session_entry.config_id
    WHERE
        pos_order_entry.rfm_team_segment_id IS NOT NULL
        AND pos_config_entry.crm_team_id = sales_team_id;
END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
